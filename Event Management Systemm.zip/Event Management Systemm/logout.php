<?php
    session_destroy();
    header('Location: /Event%20Management%20Systemm/index.php');
    
?>